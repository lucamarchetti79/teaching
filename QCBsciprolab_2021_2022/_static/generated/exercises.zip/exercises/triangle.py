"""
Computes hypotenuse of triangle
"""
import math

A = 133
B = 72

C = math.sqrt(A**2 + B**2)

print("Hypotenuse value: ", C)
