#empty set
a = set()
print(a)
a.add("Pippo")
a.add("Paperino")
a.add("Minni")

#adding the same element twice...
print(a)
a.add("Pippo") # has no effect
print(a)

#a set from a list of values
myList = [121, 5, 4, 1, 1, 4, 2, 121]
print("\nList: {}".format(myList))
S = set(myList)
print("Set: {}".format(S))

#accessing elements:
for el in S:
    print("\telement: {}".format(el))

print("Is 44 in S? {}".format(44 in S))
print("Is 121 in S? {}".format(121 in S))

#from strings
S1 = set("abracadabra")
S2 = set("AbbadabE")
print("\nS1: {}".format(S1))
print("S2: {}".format(S2))
print("\nIntersection(S1,S2): {}".format(S1 & S2))
print("\nUnion(S1,S2): {}".format(S1 | S2))
print("\nIn S1 but not in S2: {}".format(S1 - S2))
print("In S2 but not in S1: {}".format(S2 - S1))
print("\nIn S1 or S2 but not in both: {}".format(S1 ^ S2))
