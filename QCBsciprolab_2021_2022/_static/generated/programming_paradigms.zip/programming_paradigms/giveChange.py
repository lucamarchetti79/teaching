def giveChange(amount):
    #res counts the used coins
    #having value 50,20,10,5,1
    print("Computing change of {} cents".format(amount))
    coins = [50,20,10,5,1]
    res = [0,0,0,0,0]
    while amount > 0:
        nextCoin = 0
        #order makes greedy choice! First 50,then 20, 10...
        if amount > 50:
            res[0] += 1
            nextCoin = 50
        elif amount > 20:
            res[1] += 1
            nextCoin = 20
        elif amount > 10:
            res[2] += 1
            nextCoin = 10
        elif amount > 5:
            res[3] +=1
            nextCoin = 5
        else:
            res[4] += 1
            nextCoin = 1

        amount -= nextCoin

    for i in range(len(coins)):
        if res[i] > 0:
            print("{} x {} cent coins".format(res[i],coins[i]))


giveChange(36)
giveChange(72)
giveChange(232)