i = 10
print i
