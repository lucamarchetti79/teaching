import time

def listInsert(size):
    myList = []
    for i in range(size):
        myList.insert(0, i)

    for i in range(len(myList)):
        myList.pop(0)

def listAppend(size):
    myList = []
    for i in range(size):
        myList.append(i)

    for i in range(len(myList)):
        myList.pop(-1)

start = time.time()
listInsert(10)
end = time.time()
print("List insert took {:.03f}s". format(end - start))
print("With 20000 elements...")
start = time.time()
listInsert(20000)
end = time.time()
print("List insert took {:.03f}s". format(end - start))

print("------------------")
start = time.time()
listAppend(10)
end = time.time()
print("List append took {:.03f}s". format(end - start))
print("With 20000 elements...")
start = time.time()
listAppend(20000)
end = time.time()
print("List append took {:.03f}s". format(end - start))