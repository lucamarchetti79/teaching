from collections import deque
import time

Q = deque()
start_t = time.time()
for i in range(400000):
    #add to the right
    Q.append(i)
print("Q has {} elements".format(len(Q)))
while len(Q) > 0:
    #remove from the left
    Q.popleft()
print("Q has {} elements".format(len(Q)))
end_t = time.time()
print("\nElapsed time: {:.2f}s".format(end_t - start_t))