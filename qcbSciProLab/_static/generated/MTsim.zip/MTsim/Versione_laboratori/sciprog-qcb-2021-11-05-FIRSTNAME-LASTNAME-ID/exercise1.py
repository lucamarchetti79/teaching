"""
Name:
Surname:
Matricola:
"""

import mem_limit

def find_missing(S):
    raise Exception("TODO IMPLEMENT ME !")


S = [1,9,7, 7, 4, 3, 3, 3]
S1 = list(range(10))
print(find_missing(S))
print(find_missing(S1))
print(find_missing([]))
S2 = [1, -72, 4, -3, -3, 3,10]
M = find_missing(S2)
print(M)
