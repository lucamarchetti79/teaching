"""
Name:
Surname:
Matricola:
"""

def findPositions(S, S1):
    raise Exception("TODO IMPLEMENT ME !")


S = """TGAATACATATTATTCCGC
GTCCTACCAAAAAATATACATAGATAT
GATACTAGGGGACCGGTTCCGGGATGATGAT"""

print(findPositions(S, "TGA"))
print(findPositions(S, "GAT"))
print(findPositions(S, "none"))
