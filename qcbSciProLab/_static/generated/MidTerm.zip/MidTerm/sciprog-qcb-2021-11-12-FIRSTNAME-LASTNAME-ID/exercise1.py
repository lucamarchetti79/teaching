"""
Name:
Surname:
ID:
"""

def findPositions(S, S1):
    raise Exception("TODO IMPLEMENT ME !")


S = """TGAATACATATTATTCCGC
GTCCTACCAAAAAATATACATAGATAT
GATACTAGGGGACCGGTTCCGGGATGA
TGATGATACTAGGGGACCGGTTGATAC"""

print(findPositions(S, "TGA"))
print(findPositions(S, "GAT"))
print(findPositions(S, "none"))
