"""
Name:
Surname:
Matricola:
"""

def findPositions(S, S1):
    s1len = len(S1)
    S = S.replace("\n","")
    ret = [x for x in range(0,len(S)) if S[x:x+s1len] == S1]
    if len(ret) > 0:
        print("\nString '{}' found at the following positions:".format(S1))
        return ret
    else:
        print("\nWarning: string '{}' not found. Returning None".format(S1,S))



S = """TGAATACATATTATTCCGC
GTCCTACCAAAAAATATACATAGATAT
GATACTAGGGGACCGGTTCCGGGATGATGAT"""

print(findPositions(S, "TGA"))
print(findPositions(S, "GAT"))
print(findPositions(S, "none"))
